#include <valarray>
#include <vector>
#include <string>
#include <cmath>
#include <iostream>
#include <fstream>
#include "Const.hpp"
#include <sstream>
#include <unordered_map>
#include "def.hpp"

#include "../eigen-3.3.9/Eigen/Dense"
using label = long long int;
using scalar = double;
using tensor1 = std::valarray<scalar>;
using tensor2 = std::valarray<std::valarray<scalar>>;
using std::vector;

namespace Const
{

    // ------------------------------------------------- //
    // Description:                                      //
    // Save initial condition, boundary condition        //
    // and gas properties                                //
    //                                                   //
    // Case:                                             //
    // Lymberopoulos 1D                                  //
    // doi: 10.1063/1.352926                             //
    // ------------------------------------------------- //


    //-------------- Input File ------------------------

    // - Initialized file
    std::string initFile;

    // - Rate coefficient file
    std::string chemCSV;

    // - Mesh file
    std::string meshFile;

    //------------- Mesh Infomation -------------------
    // - Length, m
    scalar L;

    //- Coordinates of the nodes
    vector<NODE> coords;

    //- Number of nodes
    label numNodes;

    //- Number of cells
    label numCells;

    //------------- Calculation Setup -------------------

    // - Number of harmonics
    label numH;

    // - Number of time instants
    label numT;

    // - Voltage amplitude of RF, V
    scalar PhiRF;

    // - Frequency of RF, Hz
    scalar fRF;

    // - Initial phase
    scalar phase;
    
    // - Period of RF, s
    scalar period;


    // - Runge-Kutta Time Step
    label nRK;

    // - Runge-Kutta coefficients
    std::vector<scalar> alpha;

    // - CFL number
    scalar CFL;
    
    // - relaxation factor for implicit scheme
    scalar eps;
    
    // - Number of loops for Block Jacobi iteration
    label nBJ;
    
    // - Error tolerance for Block-Jacobi iteration
    scalar tolNe;
    scalar tolNi;
    scalar tolEe;

    // - Number of variables treated implicitly
    label numVar;

    // Initial Condition
    scalar Ni0;
    scalar Ne0;
    scalar Te0;
    scalar Phi0;

    // Nondimensionalization
    scalar LRef;    // m
    scalar TeRef;   // K 
    scalar tRef;   // s
    scalar fRef;   // Hz
    scalar EeRef;   // Jm^-3
    scalar nRef;    // m^-3
    scalar phiRef;  // V
    scalar DeRef;   // m^2/s
    scalar DiRef;   // m^2/s
    scalar muERef;  // m^2/s/V
    scalar muIRef;  // m^2/s/V
    scalar eRef;    // C
    scalar klRef;   // m^3/s
    scalar HlRef;   // J
    scalar epsRef;  // F m^-1 
    scalar cSRef;
    scalar JeRef;
    scalar JiRef;
    scalar ERef; // V/m
    scalar omegaRef; // angular frequency, rad/s

    // - Is first order or not
    std::string isFirstOrder;

    // - Option for the constranit of Je of the electon flux
    std::string isJeConstraint; // YES or NO

    // - Types of analysis modes:
    AnalysisMode analysisMode; //STEADY, DT, HB

    // - Options for initializing the solution:
    InitOption initOption; // SCRATCH, CONTINUE, RESTART, FROMSTEADY

    // - Implicit scheme for pseudo-time stepping:
    ImplicitScheme implicitScheme; // PCI1

    //- Kind of time step used in the simulation:
    TimeStepType timeStepType; 

    // - Conditions to stop the simulation:
    StopMode stopMode;


    //-------------------- Macro Properity ------------------------

    //- PI
    scalar pi = M_PI;

    // - Boltzmann constant, J/K
    scalar kB;

    // - Elementary charge, C
    scalar e;

    // - Vacuum permittivity, F/m
    scalar eps0;

    // - Electron voltage to Joule conversion factor
    scalar eV2J;
    
    // - Energy exchange per collision, J
    scalar Hl;

    // - Number density of Ar(background gas), m^-3
    scalar N;

    // - Electron diffusivity, m^2/s
    scalar De;

    // - Ion diffusivity, m^2/s
    scalar Di;

    // - Electron mobility, m^2/s/V
    scalar muE;

    // - Ion mobility, m^2/s/V
    scalar muI;

    // - Mass of electron, kg
    scalar me;

    //- Secondary electron emission coefficient
    scalar Gam;

    // - Pressure of background gas, torr
    scalar P;

    // - InitiaL number density of background gas, m^-3
    scalar N0;

    // - Electron diffusivity times number density of background gas
    scalar De0;

    // - Ion diffusivity times number density of background gas
    scalar Di0;

    // - Electron mobility times number density of background gas
    scalar muE0;

    // - Ion mobility times number density of background gas
    scalar muI0;
    

    //------------------ Stop and Postprocess ---------------------
    //- Stop Time
    scalar stopTime;

    //- Stop Step
    label stopStep;

    //- Stop Step 
    label stopPeriod;

    //- Write Interval
    scalar writeIntervalCyc;
    label  writeInterval;
    
    //- Print Interval 
    label printInterval;

    //-Number of Cells for Time Series
    label nCellTs;

    //- ID of Cell for the time series output
    std::vector<label> cellIDTs;

    // - Number of transient instants for output
    label nTI;

    void readConfigFile(const std::string &filename) {
        std::ifstream file(filename);
        if (!file) {
            std::cout << "Error: Cannot open " << filename << std::endl;
            return;
        }

        std::string line;
        std::unordered_map<std::string, std::string> config;

        
        while (std::getline(file, line)) {
            
            if (line.empty() || line[0] == '#') continue;

            std::istringstream iss(line);
            std::string key, value;
            if (std::getline(iss, key, '=') && std::getline(iss, value)) {
                
                key.erase(0, key.find_first_not_of(" \t"));
                key.erase(key.find_last_not_of(" \t") + 1);
                value.erase(0, value.find_first_not_of(" \t"));
                value.erase(value.find_last_not_of(" \t") + 1);
                config[key] = value;
            }
        }

        auto trim = [](std::string &s) {
            s.erase(0, s.find_first_not_of(" \t\n\r")); 
            s.erase(s.find_last_not_of(" \t\n\r") + 1);  
        };

        if (config.count("initFile")) {
            initFile = config["initFile"];
            trim(initFile);}

        if (config.count("chemCSV")) {
            chemCSV = config["chemCSV"];
            trim(chemCSV);}

        if (config.count("meshFile")) {
            meshFile = config["meshFile"];
            trim(meshFile);}



        if (config.count("numH")) numH = std::stoi(config["numH"]);

        numT = numH * 2 + 1;

        if (config.count("PhiRF")) PhiRF = std::stod(config["PhiRF"]);
        
        if (config.count("fRF")) fRF = std::stod(config["fRF"]);
        
        period = 1.0 / fRF;

        if (config.count("phase")) phase = std::stod(config["phase"]);

        phase = phase / 180.0 * pi;

        if (config.count("nRK")) nRK = std::stoi(config["nRK"]);

        if (config.count("alpha")) {
            alpha.clear();
            std::stringstream ss(config["alpha"]);
            std::string val;
            while (std::getline(ss, val, ',')) {
                alpha.push_back(std::stod(val));
            }
        }

        if (config.count("CFL")) CFL = std::stod(config["CFL"]);

        if (config.count("eps")) eps = std::stod(config["eps"]);

        if (config.count("nBJ")) nBJ = std::stoi(config["nBJ"]);

        if (config.count("tolNe")) tolNe = std::stod(config["tolNe"]);

        if (config.count("tolNi")) tolNi = std::stod(config["tolNi"]);

        if (config.count("tolEe")) tolEe = std::stod(config["tolEe"]);

        if (config.count("Ni0")) Ni0 = std::stod(config["Ni0"]);

        if (config.count("Ne0")) Ne0 = std::stod(config["Ne0"]);

        if (config.count("Te0")) Te0 = std::stod(config["Te0"]);

        if (config.count("Phi0")) Phi0 = std::stod(config["Phi0"]);

        if (config.count("LRef")) LRef = std::stod(config["LRef"]);

        if (config.count("TeRef")) TeRef = std::stod(config["TeRef"]);

        scalar theVelocity = std::sqrt(8.0 * kB * TeRef / (pi * me));

        tRef = LRef / theVelocity;

        fRef = 1.0 / tRef;

        if (config.count("nRef")) nRef = std::stod(config["nRef"]);

        EeRef  = 3.0/2.0 * kB * nRef * TeRef;

        if (config.count("phiRef")) phiRef = std::stod(config["phiRef"]);
        
        ERef = phiRef / LRef;

        DeRef = LRef * theVelocity;

        DiRef = LRef * theVelocity;

        muERef = DeRef / phiRef;

        muIRef = DiRef / phiRef;

        eRef = EeRef /(phiRef * nRef);

        klRef = 1/(nRef * tRef);
        
        HlRef = EeRef / nRef;

        epsRef = EeRef * pow(LRef,2.0) / pow(phiRef,2.0);


        JeRef = nRef * theVelocity;

        JiRef = nRef * theVelocity;

        cSRef = klRef * pow(nRef,2.0);

        omegaRef = 2.0 * pi / tRef;

        if (config.count("isFirstOrder")){
            isFirstOrder = config["isFirstOrder"];
            trim(isFirstOrder);}

        if (config.count("isJeConstraint")){
            isJeConstraint = config["isJeConstraint"];
            trim(isJeConstraint);}

        if (config.count("analysisMode")) {
            std::string modeStr = config["analysisMode"];
            trim(modeStr);

            if (modeStr == "STEADY") analysisMode = AnalysisMode::STEADY;
            else if (modeStr == "DT") analysisMode = AnalysisMode::DT;
            else if (modeStr == "HB") analysisMode = AnalysisMode::HB;
            else throw std::runtime_error("Invalid analysisMode: " + modeStr);
        }

        if (analysisMode != AnalysisMode::HB) {
            numH = 0;
            numT = 1;
        }

        if (config.count("initOption")) {
            std::string initStr = config["initOption"];
            trim(initStr);

            if (initStr == "SCRATCH") initOption = InitOption::SCRATCH;
            else if (initStr == "CONTINUE") initOption = InitOption::CONTINUE;
            else if (initStr == "RESTART")  initOption = InitOption::RESTART;
            else if (initStr == "FROMSTEADY") initOption = InitOption::FROMSTEADY;
            else throw std::runtime_error("Unknown initOption: " + initStr);
        }

        if (config.count("implicitScheme")) {
            std::string schemeStr = config["implicitScheme"];
            trim(schemeStr);
            if (schemeStr == "NO") implicitScheme = ImplicitScheme::NO;
            else if (schemeStr == "PCI1") implicitScheme = ImplicitScheme::PCI1;
            else throw std::runtime_error("Unknown implicitScheme: " + schemeStr);
        }

        if(implicitScheme == ImplicitScheme::PCI1) {
            numVar = 3; 
        }

        if (config.count("timeStepType")) {
            std::string stepStr = config["timeStepType"];
            trim(stepStr);

            if (stepStr == "LOCAL") timeStepType = TimeStepType::LOCAL;
            else if (stepStr == "GLOBAL") timeStepType = TimeStepType::GLOBAL;
            else throw std::runtime_error("Unknown timeStepType: " + stepStr);
        }

        if (analysisMode != AnalysisMode::DT)
        {
            timeStepType = TimeStepType::LOCAL;
        }
        else
        {
            timeStepType = TimeStepType::GLOBAL;
        }
        

        if (config.count("stopMode")) {
            std::string stopStr = config["stopMode"];
            trim(stopStr);

            if (stopStr == "TIME")   stopMode = StopMode::TIME;
            else if (stopStr == "STEP")   stopMode = StopMode::STEP;
            else if (stopStr == "PERIOD") stopMode = StopMode::PERIOD;
            else throw std::runtime_error("Unknown stopMode: " + stopStr);
        }


        if (config.count("kB")) kB = std::stod(config["kB"]);

        if (config.count("e")) e = std::stod(config["e"]);

        if (config.count("eps0")) eps0 = std::stod(config["eps0"]);

        if (config.count("eV2J")) eV2J = std::stod(config["eV2J"]); 

        if (config.count("Hl")) Hl = std::stod(config["Hl"]);

        Hl = Hl * eV2J;

        if (config.count("me")) me = std::stod(config["me"]);

        if (config.count("Gam")) Gam = std::stod(config["Gam"]);

        if (config.count("P")) P = std::stod(config["P"]);

        if (config.count("N0")) N0 = std::stod(config["N0"]);

        if (config.count("De0")) De0 = std::stod(config["De0"]);

        if (config.count("Di0")) Di0 = std::stod(config["Di0"]);

        if (config.count("muE0")) muE0 = std::stod(config["muE0"]);

        if (config.count("muI0")) muI0 = std::stod(config["muI0"]);

        N = N0 * P;

        De = De0 / N;

        Di = Di0 / N;

        muE = muE0 / N;

        muI = muI0 / N;

        if (config.count("stopTime")) stopTime = std::stod(config["stopTime"]);

        if (config.count("stopStep")) stopStep = std::stoi(config["stopStep"]);

        if (config.count("stopPeriod")) stopPeriod = std::stoi(config["stopPeriod"]);

        if (config.count("writeIntervalCyc")) writeIntervalCyc = std::stod(config["writeIntervalCyc"]);

        if (config.count("writeInterval")) writeInterval = std::stoi(config["writeInterval"]);

        if (config.count("printInterval")) printInterval = std::stoi(config["printInterval"]);

        if (config.count("nCellTs")) nCellTs = std::stoi(config["nCellTs"]);

        if (config.count("cellIDTs")) {
            cellIDTs.clear();
            std::stringstream ss(config["cellIDTs"]);
            std::string val;
            while (std::getline(ss, val, ',')) {
                cellIDTs.push_back(std::stoi(val));
            }
        }

        if (config.count("nTI")) nTI = std::stoi(config["nTI"]);


        std::cout << "================ Config Loaded ================" << std::endl;
        std::cout << "initFile: " << initFile << std::endl;
        std::cout << "chemCSV: " << chemCSV << std::endl;
        std::cout << "meshFile: " << meshFile << std::endl;
        std::cout << "numH: " << numH << std::endl;
        std::cout << "numT: " << numT << std::endl;
        std::cout << "PhiRF: " << PhiRF << std::endl;
        std::cout << "fRF: " << fRF << std::endl;
        std::cout << "phase (radians): " << phase << std::endl;
        std::cout << "period: " << period << std::endl;
        std::cout << "nRK: " << nRK << std::endl;
        std::cout << "alpha: ";
        for (const auto &a : alpha) {
            std::cout << a << " ";
        }
        std::cout << std::endl;
        std::cout << "CFL: " << CFL << std::endl;
        std::cout << "eps: " << eps << std::endl;
        std::cout << "nBJ: " << nBJ << std::endl;
        std::cout << "tolNe: " << tolNe << std::endl;
        std::cout << "tolNi: " << tolNi << std::endl;
        std::cout << "tolEe: " << tolEe << std::endl;
        std::cout << "Ni0: " << Ni0 << std::endl;
        std::cout << "Ne0: " << Ne0 << std::endl;
        std::cout << "Te0: " << Te0 << std::endl;
        std::cout << "Phi0: " << Phi0 << std::endl;
        std::cout << "LRef: " << LRef << std::endl;
        std::cout << "TeRef: " << TeRef << std::endl;
        std::cout << "tRef: " << tRef << std::endl;
        std::cout << "fRef: " << fRef << std::endl;
        std::cout << "EeRef: " << EeRef << std::endl;
        std::cout << "nRef: " << nRef << std::endl;
        std::cout << "phiRef: " << phiRef << std::endl;
        std::cout << "DeRef: " << DeRef << std::endl;
        std::cout << "DiRef: " << DiRef << std::endl;
        std::cout << "muERef: " << muERef << std::endl;
        std::cout << "muIRef: " << muIRef << std::endl;
        std::cout << "eRef: " << eRef << std::endl;
        std::cout << "klRef: " << klRef << std::endl;
        std::cout << "HlRef: " << HlRef << std::endl;
        std::cout << "epsRef: " << epsRef << std::endl;
        std::cout << "cSRef: " << cSRef << std::endl;
        std::cout << "JeRef: " << JeRef << std::endl;
        std::cout << "JiRef: " << JiRef << std::endl;
        std::cout << "ERef: " << ERef << std::endl;
        std::cout << "omegaRef: " << omegaRef << std::endl;
        std::cout << "isFirstOrder: " << isFirstOrder << std::endl;
        std::cout << "isJeConstraint: " << isJeConstraint << std::endl;
        std::cout << "analysisMode: " << toString(analysisMode) << std::endl;
        std::cout << "initOption: " << toString(initOption) << std::endl;
        std::cout << "implicitScheme  : " << toString(implicitScheme) << std::endl;
        std::cout << "timeStepType   : " << toString(timeStepType) << std::endl;
        std::cout << "stopMode        : " << toString(stopMode) << std::endl;
        std::cout << "pi: " << pi << std::endl;
        std::cout << "kB: " << kB << std::endl;
        std::cout << "e: " << e << std::endl;
        std::cout << "eps0: " << eps0 << std::endl;
        std::cout << "eV2J: " << eV2J << std::endl;
        std::cout << "Hl: " << Hl << std::endl;
        std::cout << "N: " << N << std::endl;
        std::cout << "De: " << De << std::endl;
        std::cout << "Di: " << Di << std::endl;
        std::cout << "muE: " << muE << std::endl;
        std::cout << "muI: " << muI << std::endl;
        std::cout << "me: " << me << std::endl;
        std::cout << "Gam: " << Gam << std::endl;
        std::cout << "P: " << P << std::endl;
        std::cout << "N0: " << N0 << std::endl;
        std::cout << "De0: " << De0 << std::endl;
        std::cout << "Di0: " << Di0 << std::endl;
        std::cout << "muE0: " << muE0 << std::endl;
        std::cout << "muI0: " << muI0 << std::endl;
        std::cout << "stopTime: " << stopTime << std::endl;
        std::cout << "stopStep: " << stopStep << std::endl;
        std::cout << "stopPeriod: " << stopPeriod << std::endl;
        std::cout << "writeIntervalCyc: " << writeIntervalCyc << std::endl;
        std::cout << "writeInterval: " << writeInterval << std::endl;
        std::cout << "printInterval: " << printInterval << std::endl;
        std::cout << "nCellTs: " << nCellTs << std::endl;
        std::cout << "cellIDTs: ";
        for (const auto &id : cellIDTs) {
            std::cout << id << " ";
        }
        std::cout << std::endl;
        std::cout << "nTI: " << nTI << std::endl;
        std::cout << "===============================================" << std::endl;
        std::cout << "Configuration loaded successfully!" << std::endl;
    }



    void readMeshFile(const std::string &meshFile)
    {
        std::cout << "================ Mesh Loaded ================" << std::endl;
        std::ifstream infile(meshFile);
        if (!infile) {
            std::cerr << "Error opening mesh file: " << meshFile << std::endl;
            return;
        }

        std::string line;
        // Skip the first two comment lines
        std::getline(infile, line);
        std::getline(infile, line);

        // Read number of nodes
        std::getline(infile, line);
        numNodes = std::stoi(line);
        numCells = numNodes - 1;
        coords.resize(numNodes);

        // Read each coordinate line
        for (label i = 0; i < numNodes; ++i) {
            std::getline(infile, line);
            coords[i].x = std::stod(line);
        }
        infile.close();

        L = coords[numNodes - 1].x - coords[0].x;
     
        std::cout << "Number of nodes: " << numNodes << std::endl;
        std::cout << "Number of cells: " << numCells << std::endl;
        std::cout << "Length of the domain: " << L << " m" << std::endl;
        std::cout << "===============================================" << std::endl;
        std::cout << "Mesh file loaded successfully!" << std::endl;

    }


    void scaleToDimensionless()
    {
        L      /= LRef;

        for (label i = 0; i < numNodes; ++i) {
            coords[i].x /= LRef;
        }

        e      /= eRef;

        eps0   /= epsRef;

        N      /= nRef;

        Hl     /= HlRef;

        De     /= DeRef;

        Di     /= DiRef;

        muE    /= muERef;

        muI    /= muIRef;

        PhiRF  /= phiRef;

        fRF    /= fRef;

        period /= tRef;

        Ni0    /= nRef;

        Ne0    /= nRef;

        Te0    /= TeRef;

        Phi0   /= phiRef;

        std::cout << "======= Dimensionless variables are as below =======" << std::endl;
        std::cout << "e: " << e << std::endl;
        std::cout << "eps0: " << eps0 << std::endl;
        std::cout << "N: " << N << std::endl;
        std::cout << "Hl: " << Hl << std::endl;
        std::cout << "De: " << De << std::endl;
        std::cout << "Di: " << Di << std::endl;
        std::cout << "muE: " << muE << std::endl;
        std::cout << "muI: " << muI << std::endl;
        std::cout << "PhiRF: " << PhiRF << std::endl;
        std::cout << "fRF: " << fRF << std::endl;
        std::cout << "period: " << period << std::endl;
        std::cout << "Ni0: " << Ni0 << std::endl;
        std::cout << "Ne0: " << Ne0 << std::endl;
        std::cout << "Te0: " << Te0 << std::endl;
        std::cout << "Phi0: " << Phi0 << std::endl;
        std::cout << "=====================================================" << std::endl;
        std::cout << "Nondimensionlization successfully done!" << std::endl;
    }

    std::string toString(AnalysisMode mode) {
        switch (mode) {
            case AnalysisMode::STEADY: return "STEADY";
            case AnalysisMode::DT:     return "DT";
            case AnalysisMode::HB:     return "HB";
            default:                   return "UNKNOWN";
        }
    }

    std::string toString(InitOption option) {
        switch (option) {
            case InitOption::SCRATCH:     return "SCRATCH";
            case InitOption::CONTINUE:    return "CONTINUE";
            case InitOption::RESTART:     return "RESTART";
            case InitOption::FROMSTEADY:  return "FROMSTEADY";
            default:                      return "UNKNOWN";
        }
    }

    std::string toString(ImplicitScheme scheme) {
        switch (scheme) {
            case ImplicitScheme::PCI1: return "PCI1";
            default:                   return "UNKNOWN";
        }
    }

    std::string toString(TimeStepType type) {
        switch (type) {
            case TimeStepType::LOCAL:  return "LOCAL";
            case TimeStepType::GLOBAL: return "GLOBAL";
            default:               return "UNKNOWN";
        }
    }

    std::string toString(StopMode mode) {
        switch (mode) {
            case StopMode::TIME:   return "TIME";
            case StopMode::STEP:   return "STEP";
            case StopMode::PERIOD: return "PERIOD";
            default:               return "UNKNOWN";
        }
    }

}
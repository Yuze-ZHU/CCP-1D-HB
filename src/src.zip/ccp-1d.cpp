// -------------------------------------------------------//
//  _______  _______  _______          __    ______       //
// (  ____ \(  ____ \(  ____ )        /  \  (  __  \      //
// | (    \/| (    \/| (    )|        \/) ) | (  \  )     //
// | |      | |      | (____)| _____    | | | |   ) |     //
// | |      | |      |  _____)(_____)   | | | |   | |     //
// | |      | |      | (                | | | |   ) |     //
// | (____/\| (____/\| )              __) (_| (__/  )     //
// (_______/(_______/|/               \____/(______/      //
//                                                        //
// -------------------------------------------------------//
//                                                        //
// Description:                                           //
// Contains Const, Solver, Tools                          //
//                                                        //
// -------------------------------------------------------//

#include <iostream>
#include <cmath>
#include <unordered_map>
#include <chrono>

// Output part
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cstring>
#include <petsc.h>
#include <vector>
#include "ccp-1d.hpp"
#include "Const.hpp"
#include "def.hpp"

#include <cmath>

// ------------------------------------------------------ //
// Description:                                           //
// Tools for basic kinetic theory                         //
// ------------------------------------------------------ //

using std::vector;

namespace Tools
{

    scalar abs(const scalar num)
    {
        return num > 0 ? num : -num;
    }

    tensor1 sign(const tensor1 &array)
    {
        tensor1 sign = array;
        sign[sign >= 0.0] = 1.0;
        sign[sign < 0.0] = -1.0;

        return sign;
    }

    scalar sign(const scalar &value)
    {
        return value > 0.0 ? 1.0 : -1.0;
    }

    scalar max(const scalar a, const scalar b)
    {
        return a > b ? a : b;
    }

    scalar min(const scalar a, const scalar b)
    {
        return a < b ? a : b;
    }

    scalar KToeV(const scalar K)
    {
        return K * 8.6174e-5;
    }

    scalar eVtoK(const scalar eV)
    {
        return eV * 1.1604e4;
    }

    scalar TeToEe(const scalar Ne, const scalar Te)
    {
        return 1.5 * Ne * Const::kB * Te;
    }


    scalar TeToEeND(const scalar Ne, const scalar Te)
    {
        return Ne * Te;
    }

    scalar EeToTeND(const scalar Ne, const scalar Ee)
    {
        return Ee / Ne;
    }

    scalar EeToTe(const scalar Ne, const scalar Ee)
    {
        return 0.6666667 * Ee / ( Ne*Const::kB);
    }

    std::string toString(double value, int precision) 
    {
        std::ostringstream out;
        out << std::fixed 
            << std::setprecision(precision) << value;
        return out.str();
    }

    std::string toStringFill0(double value)
    {
        //- The Func setw() controls the digits before the decimal point
        //- The Func fixed() with setprecision() 
        //- controls the digits before the decimal point
        std::stringstream ss;
        ss << std::setfill('0') << std::setw(4) 
           << std::fixed << std::setprecision(2) << value;

        std::string result = ss.str();
        return result;
    }

    std::vector<PetscScalar> Tools::toRowMajor(const Eigen::MatrixXd& M)
    {
        std::vector<PetscScalar> buf(M.rows() * M.cols());

        for (PetscInt r = 0; r < M.rows(); ++r)
            for (PetscInt c = 0; c < M.cols(); ++c)
                buf[r * M.cols() + c] = static_cast<PetscScalar>( M(r, c) ); 

        return buf; 
    }
}

// ------------------------------------------------------- //
// Description:                                            //
// Constructor and deconstructor for cell class            //
// ------------------------------------------------------- //

FVM::ChemSet::ChemSet(const std::string csvName)
{
    using std::ifstream;
    using std::string;
    using std::stringstream;
    using std::vector;

    ifstream chemCSV(csvName);

    if ( chemCSV.is_open() )
    {
        std::string word;
        if (chemCSV >> word) {
            std::cout << "Successfully Load Chemical Data: " 
            << word << std::endl;
        } else {
            std::cout << "Cannot Load Chemical Data." << std::endl;
        }
    }
    else
    {
        std::cout << "Cannot open the .csv file." << std::endl; 
    }

    string datas;
    vector<string> headers;

    if (getline(chemCSV, datas))
    {
        stringstream ss(datas);
        string word;
        while (getline(ss, word, ','))
        {
            headers.push_back(word);
        }
    }

    while (getline(chemCSV, datas))
    {
        stringstream ss(datas);
        string data;
        vector<string> row;

        while (getline(ss, data, ','))
        {
            row.push_back(data);
        }

        if (row.size() == 2)
        {
            ChemRate dp;
            dp.energy = stod(row[0]);
            dp.cRate = stod(row[1]);
            chemSets.push_back(dp);
        }
    }

    chemCSV.close();
}

FVM::ChemSet::~ChemSet()
{}

scalar FVM::ChemSet::interpolateChem(const scalar E)
{
    size_t low = 0;
    size_t high = chemSets.size() - 1;

    // Bindary search to find the interval where the energy E lies
    while (low < high)
    {
        size_t mid = low + (high - low) * 0.5;

        if (chemSets[mid].energy < E)
        {
            low = mid + 1;
        }
        else
        {
            high = mid;
        }
    }

    if (low == 0)
    {
        return chemSets[0].cRate;
    }
    else if 
    (
        low == chemSets.size() || 
        chemSets[low].energy == E
    )
    {
        return chemSets[low].cRate;
    }
    else
    {
        const double E0 = chemSets[low - 1].energy;
        const double E1 = chemSets[low].energy;
        const double k0 = chemSets[low - 1].cRate;
        const double k1 = chemSets[low].cRate;

        // Linear interpolation
        return k0 + (k1 - k0) * (E - E0) / (E1 - E0);
    }

}

FVM::PhiDecSolver::PhiDecSolver(){}

FVM::PhiDecSolver::~PhiDecSolver(){}

void FVM::PhiDecSolver::createLU()
{
    solver = M.llt();
}




void FVM::PhiDecSolver::solverApply(Eigen::VectorXd &F,Eigen::VectorXd &Phi_)
{
    Phi_ = solver.solve(F);
}

FVM::Cell::Cell(const label i)
    : vol(0.0), cellID(i), dt(0.0), dtau(0.0), kl(0.0),

    // Vectors initialization
    // Conservative variables
    Ne(Const::numT), Ni(Const::numT), Ee(Const::numT), Phi(Const::numT),

    // Primitive variables
    Ec(Eigen::VectorXd::Zero(Const::numT)), Te(Const::numT),

    // Other variables
    Je(Eigen::VectorXd::Zero(Const::numT)), 
    Ji(Eigen::VectorXd::Zero(Const::numT)), 
    cS(Eigen::VectorXd::Zero(Const::numT)),

    // Conservative variables at the previous time step
    NeOld(Const::numT), NiOld(Const::numT), EeOld(Const::numT), PhiOld(Const::numT), 
    
    // Residual flux of conservative variables (including flux and source term, updating the conservative variables)
    ResFluxNe(Eigen::VectorXd::Zero(Const::numT)),
    ResFluxNi(Eigen::VectorXd::Zero(Const::numT)),
    ResFluxEe(Eigen::VectorXd::Zero(Const::numT)),
    ResFluxPhi(Eigen::VectorXd::Zero(Const::numT)),
    
    // Slope of conservative variables
    sNe(Eigen::VectorXd::Zero(Const::numT)),
    sNi(Eigen::VectorXd::Zero(Const::numT)),
    sEe(Eigen::VectorXd::Zero(Const::numT)),
    sPhi(Eigen::VectorXd::Zero(Const::numT)),

    // Residual of conservative variables (output of the residual calculation)
    resNe(Eigen::VectorXd::Zero(Const::numT)),
    resNi(Eigen::VectorXd::Zero(Const::numT)),
    resEe(Eigen::VectorXd::Zero(Const::numT)),

    // Matrix for the chemical reaction
    MatrixK(Eigen::MatrixXd::Zero(Const::numT, Const::numT))
{
    for (label iT = 0; iT < Const::numT; ++iT)
    {
        Ne(iT)     = Const::Ne0; 
        Ni(iT)     = Const::Ni0;
        Te(iT)     = Const::Te0;
        Ee(iT)     = Tools::TeToEeND(Ne(iT), Te(iT));   
        Phi(iT)    = Const::Phi0; 

        NeOld(iT)  = Ne(iT);
        NiOld(iT)  = Ni(iT);
        EeOld(iT)  = Ee(iT);
        PhiOld(iT) = Phi(iT);
    }
}


FVM::Cell::~Cell()
{

}



// ------------------------------------------------------- //
// Description:                                            //
// Constructor and deconstructor for face class            //
// ------------------------------------------------------- //

FVM::Face::Face(const Cell &Lcell, const Cell &Rcell)
    : cellL(Lcell), cellR(Rcell), faceID(Rcell.cellID),
    cellIDL(Lcell.cellID), cellIDR(Rcell.cellID), dist(0.0),
    distL(0.0), distR(0.0),

    // Vectors initialization
    // Conservative and primitive variables at left and right sides
    NeL(Eigen::VectorXd::Zero(Const::numT)),
    NeR(Eigen::VectorXd::Zero(Const::numT)),
    NiL(Eigen::VectorXd::Zero(Const::numT)),
    NiR(Eigen::VectorXd::Zero(Const::numT)),
    EeL(Eigen::VectorXd::Zero(Const::numT)),
    EeR(Eigen::VectorXd::Zero(Const::numT)),
    TeL(Eigen::VectorXd::Zero(Const::numT)),
    TeR(Eigen::VectorXd::Zero(Const::numT)),
    PhiL(Eigen::VectorXd::Zero(Const::numT)),
    PhiR(Eigen::VectorXd::Zero(Const::numT)),
    Ef(Eigen::VectorXd::Zero(Const::numT)),

    // Flux for number density and electron energy
    fluxNe(Eigen::VectorXd::Zero(Const::numT)),
    fluxNi(Eigen::VectorXd::Zero(Const::numT)),
    fluxEe(Eigen::VectorXd::Zero(Const::numT)),
    fluxEeJoule(Eigen::VectorXd::Zero(Const::numT)),
    fluxPhi(Eigen::VectorXd::Zero(Const::numT))
{

}




FVM::Face::~Face()
{

}

scalar FVM::Face::getDiff(const scalar pLcell, const scalar pRcell)
{
    // Diffusion gets the gradient at the cell center
    return (pRcell - pLcell) / dist;
}

scalar FVM::Face::getUpwind(const scalar pLcell, const scalar pRcell, const label iT)
{
    // Upwind uses variables at the cell interface
    return cellL.Phi(iT) > cellR.Phi(iT) ? pRcell : pLcell;
}

scalar FVM::Face::getDownwind(const scalar pLcell, const scalar pRcell, const label iT)
{
    // Upwind uses variables at the cell interface
    return cellL.Phi(iT) > cellR.Phi(iT) ? pLcell : pRcell;
}

void FVM::Face::interpolate()
{
    using namespace Const;
    using namespace Tools;
    
    for (label iT = 0; iT < numT; ++iT)
    {
        if(faceID == 0)
        {
            NeR(iT)  = cellR.Ne(iT)  - 0.5 * distR * cellR.sNe(iT);
            NiR(iT)  = cellR.Ni(iT)  - 0.5 * distR * cellR.sNi(iT);
            EeR(iT)  = cellR.Ee(iT)  - 0.5 * distR * cellR.sEe(iT);
            PhiR(iT) = cellR.Phi(iT) - 0.5 * distR * cellR.sPhi(iT);
            TeR(iT)  = EeToTeND(NeR(iT), EeR(iT));

            // For the boundary cells, distL and slopes are zero
            NeL(iT)  = cellL.Ne(iT)  + 0.5 * distL * cellL.sNe(iT);
            NiL(iT)  = cellL.Ni(iT)  + 0.5 * distL * cellL.sNi(iT);
            EeL(iT)  = cellL.Ee(iT)  + 0.5 * distL * cellL.sEe(iT);
            PhiL(iT) = cellL.Phi(iT) + 0.5 * distL * cellL.sPhi(iT);
            // Zero gradient for electron energy at the boundary
            TeL(iT)  = TeR(iT);
        }
        else if(faceID = numCells)
        {
            NeL(iT)  = cellL.Ne(iT)  + 0.5 * distL * cellL.sNe(iT);
            NiL(iT)  = cellL.Ni(iT)  + 0.5 * distL * cellL.sNi(iT);
            EeL(iT)  = cellL.Ee(iT)  + 0.5 * distL * cellL.sEe(iT);
            PhiL(iT) = cellL.Phi(iT) + 0.5 * distL * cellL.sPhi(iT);
            TeL(iT)  = EeToTeND(NeL(iT), EeL(iT));
            // For the boundary cells, distR and slopes are zero
            NeR(iT)  = cellR.Ne(iT)  - 0.5 * distR * cellR.sNe(iT);
            NiR(iT)  = cellR.Ni(iT)  - 0.5 * distR * cellR.sNi(iT);
            EeR(iT)  = cellR.Ee(iT)  - 0.5 * distR * cellR.sEe(iT);
            PhiR(iT) = cellR.Phi(iT) - 0.5 * distR * cellR.sPhi(iT);
            // Zero gradient for electron energy at the boundary
            TeR(iT)  = TeL(iT);
        }
        else
        {
            NeL(iT)  = cellL.Ne(iT)  + 0.5 * distL * cellL.sNe(iT);
            NiL(iT)  = cellL.Ni(iT)  + 0.5 * distL * cellL.sNi(iT);
            EeL(iT)  = cellL.Ee(iT)  + 0.5 * distL * cellL.sEe(iT);
            PhiL(iT) = cellL.Phi(iT) + 0.5 * distL * cellL.sPhi(iT);
            TeL(iT)  = EeToTeND(NeL(iT), EeL(iT));

            NeR(iT)  = cellR.Ne(iT)  - 0.5 * distR * cellR.sNe(iT);
            NiR(iT)  = cellR.Ni(iT)  - 0.5 * distR * cellR.sNi(iT);
            EeR(iT)  = cellR.Ee(iT)  - 0.5 * distR * cellR.sEe(iT);
            PhiR(iT) = cellR.Phi(iT) - 0.5 * distR * cellR.sPhi(iT);
            TeR(iT)  = EeToTeND(NeR(iT), EeR(iT));
        }
    }
}

FVM::Solver::Solver()
    : 
    step(0), runTime(0.0), runCyc(0.0), dtminGlobal(0.0), 
    isWarning(false),outputDir("."), chemSets(Const::chemCSV),

    //- Time spectral source matrix, E
    harmMat(Eigen::MatrixXd::Zero(Const::numT, Const::numT)),

    //- DFT matrix, D
    dftMat(Eigen::MatrixXd::Zero(Const::numT, Const::numT)),

    //- Inverse of DFT matrix, D^-1
    dftMatInv(Eigen::MatrixXd::Zero(Const::numT, Const::numT)),

    //- Time instants
    harmTime(Eigen::VectorXd::Zero(Const::numT)),

    //- Angular frequencies
    angFreq(Eigen::VectorXd::Zero(Const::numH))
{
    std::cout << " ------ Starting constructing solver ------ " << std::endl;
    std::cout << " ------ Constucting cells ------" << std::endl;
    for (label i = 0; i < Const::numCells + 2; i++)
    {
        cells.emplace_back(i);
    }
    std::cout << " ------ Constructing cells finished ------" << std::endl;
    std::cout << " ------ Constructing faces --------" << std::endl;
    for (label i = 0; i < Const::numNodes; i++)
    {
        if (i == 0) // cell at left boundary
        {
            faces.emplace_back(cells.at(Const::numCells + 1), cells.at(i));
        }
        else // cells at the interior faces and right boundary
        {
            faces.emplace_back(cells.at(i - 1), cells.at(i));
        }
    }
    std::cout << " ------ Constructing faces finished ------" << std::endl;

    if(Const::implicitScheme == ImplicitScheme::NO &&
       Const::implicitScheme == ImplicitScheme::PCI1)
       {
            // Total number of global degrees of freedom(DoF)
            PetscInt numPhiDoF = Const::numCells * Const::numT;
        
            // (1):  Create matrix coefficient matrix A for the discretized Poisson's equation
            // based on PETSc in sequential (non-parallel) mode
            MatCreate(PETSC_COMM_SELF, &poissonMat);

            // Set matrix poissonMat global size: numPhiDoF × numPhiDoF 
            // Only one process owns all rows/cols
            MatSetSizes(poissonMat, PETSC_DECIDE, PETSC_DECIDE, numPhiDoF, numPhiDoF);

            // Set block size: each nonzero block is a numCells * numCells submatrix
            MatSetBlockSize(poissonMat, Const::numCells);

            // Use sequential block AIJ (BAIJ) format (serial block-sparse matrix)
            MatSetType(poissonMat, MATSEQBAIJ);

            // Preallocate memory: assume maximum 3 block entries per row (
            // Self + 2 neighbors(valid only for 1D problem)
            MatSeqBAIJSetPreallocation(poissonMat, Const::numCells, 1, nullptr);

            // Setup matrix
            MatSetUp(poissonMat);   

            // (2):  Create Solution vector x
            VecCreate(PETSC_COMM_SELF, &phiVec);
            VecSetSizes(phiVec, PETSC_DECIDE, numPhiDoF); 
            VecSetBlockSize(phiVec, Const::numCells);   
            VecSetFromOptions(phiVec);
            VecSetUp(phiVec);

            // (3):  Create RHS vector b
            VecDuplicate(phiVec, &phiRhsVec);
            std::cout << " ------ Allocating memeory for solving Poisson's equation Finished ------" << std::endl;

       }
    std::cout << " ------ Finish Construct Solver" << std::endl;
}

FVM::Solver::~Solver()
{

}

void FVM::Solver::initlize()
{
    using namespace Const;

    if (initOption != InitOption::SCRATCH) {
        // std::cout << "Read quasi-steady solution from file." << std::endl;
        // readQuasiSteadySolution(initFile);
    }

}

void FVM::Solver::initHarmonicMat()
{
    using namespace Const;
    const double freq = fRF;
    const double T    = period;
    double dtheta;

    Eigen::MatrixXd D     = Eigen::MatrixXd::Zero(numT, numT);
    Eigen::MatrixXd Dt    = Eigen::MatrixXd::Zero(numT, numT);
    Eigen::MatrixXd D_inv = Eigen::MatrixXd::Zero(numT, numT);


    // Initialize the harmonic time vector, angular frequency vector
    harmTime.setZero();
    angFreq.setZero();

    // Initialize the harmonic matrix, DFT matrix, and IDFT matrix
    harmMat.setZero();
    dftMat.setZero();
    dftMatInv.setZero();

    std::cout << "Time instants used in the harmonic balance analysis are:" << std::endl;
    for (label nT = 0; nT < numT; ++nT)
    {
        harmTime(nT) = nT * T / numT;
        std::cout << "t(" << nT << ") = " << harmTime(nT) << std::endl;
    }

    std::cout << "Angular frequencies used in the harmonic balance analysis are:" << std::endl;
    for (label nh = 0; nh < numH; ++nh)
    {
        angFreq(nh) = 2.0 * pi * (nh+1) * freq;
        std::cout << "angFreq(" << nh << ") = " << angFreq(nh) << std::endl;
    }

    for (label nT = 0; nT < numT; ++nT)
    {
        D(nT, 0)  = 1.0;
        Dt(nT, 0) = 0.0;
        for (label nh = 0; nh < numH; ++nh)
        {   
            dtheta             = angFreq(nh) * harmTime(nT);
            D(nT, 2 * nh + 1)  = sin(dtheta);
            D(nT, 2 *nh + 2)   = cos(dtheta);
            Dt(nT, 2 * nh + 1) = angFreq(nh) * cos(dtheta);
            Dt(nT, 2 * nh + 2) = -angFreq(nh) * sin(dtheta);
        }
    }

    std::cout << "\nInverse Discrete Fourier transform operator D:" << std::endl;
    for (label i = 0; i < numT; ++i) {
        for (label j = 0; j < numT; ++j) {
            std::cout << std::setw(20) 
                      << std::fixed 
                      << std::setprecision(8) 
                      << D(i, j) << " ";
        }
        std::cout << std::endl;
    }

    std::cout << "\nFirst-order derivative opeartot Dt:" << std::endl;
    for (label i = 0; i < numT; ++i) {
        for (label j = 0; j < numT; ++j) {
            std::cout << std::setw(20)
                      << std::fixed 
                      << std::setprecision(8) 
                      << Dt(i, j) << " ";
        }
        std::cout << std::endl;
    }

    D_inv = D.inverse();

    std::cout << "\nDiscrete Fourier transform operator D^-1:" << std::endl;
    for (label i = 0; i < numT; ++i) 
    {
        for (label j = 0; j < numT; ++j) 
        {
            std::cout << std::setw(20) 
                      << std::fixed 
                      << std::setprecision(8) 
                      << D_inv(i, j) << " ";
        }
        std::cout << std::endl;
    }

    harmMat = Dt * D_inv;
    
    std::cout << "\nTime spectral source operator E:" << std::endl;
    for (label i = 0; i < numT; ++i) {
        for (label j = 0; j < numT; ++j) {
            std::cout << std::setw(20) 
                      << std::fixed 
                      << std::setprecision(8) 
                      << harmMat(i, j) << " ";
        }
        std::cout << std::endl;
    }

    dftMat    = D_inv; 
    dftMatInv = D;
}

void FVM::Solver::initRK()
{
    using namespace Const;
    for (label i = 0; i < numCells; ++i)
    {
        cells[i].NeOld   = cells[i].Ne;
        cells[i].NiOld   = cells[i].Ni;
        cells[i].EeOld   = cells[i].Ee;
        cells[i].PhiOld  = cells[i].Phi;        
    }
}

void FVM::Solver::getDt()
{
    using namespace Const;
    using Tools::min;

    dtminGlobal = 1e150;

    for (label i = 0; i < numCells; ++i)
    {
        scalar dtminLocal   = 1e150;
        const scalar dtDiff = 0.25 * cells[i].vol * cells[i].vol / De;
        for(label nT = 0; nT < numT; ++nT)
        {
            const scalar dtConv = cells[i].vol / (muE * abs(cells[i].Ec[nT]) + 1e-120 );
            scalar dtmin1       = min(dtDiff, dtConv);
            dtminLocal          = min(dtminLocal, dtmin1);   
        }
        // Modified local time step based on the biggest harmonic frequency
        dtminLocal  = CFL * (1. / (1. / dtminLocal + 2.0 * pi * fRF * numH));
        cells[i].dt = dtminLocal; 
        dtminGlobal = min(cells[i].dt, dtminGlobal);
    }
    
    if (timeStepType == TimeStepType::GLOBAL)
    {
        for (label i = 0; i < numCells; ++i)
        {
            cells[i].dt = dtminGlobal;
        }
    }

}

void FVM::Solver::calSlope()
{
    using namespace Const;
    using Tools::abs;
    using Tools::sign;

    // MUSCL-type slope limiter for computing a weighted average of left and right gradients
    auto slopeLimiter = [&](scalar fL, scalar fC, scalar fR, scalar dxL, scalar dxR) 
    {
        scalar sL = (fC - fL) / dxL;
        scalar sR = (fR - fC) / dxR;
        return (sign(sL) + sign(sR)) * abs(sL) * abs(sR) / (abs(sL) + abs(sR) + 1e-50);
    };

    for (label i = 0; i < numCells; ++i)
    {
        if (Const::isFirstOrder == "no")
            break;

        Cell *cellL = &cells[i], *cellR = &cells[i + 1], *cellC = &cells[i];

        if (i == 0)
        {
            cellL = &cells[numCells + 1];
        }
        else
        {
            cellL = &cells[i - 1];
        }

        for (label iT = 0; iT < numT; ++iT)
        {
            cellC->sNe(iT)   = slopeLimiter(cellL->Ne(iT), cellC->Ne(iT), cellR->Ne(iT), faces[i].dist, faces[i + 1].dist);
            cellC->sNi(iT)   = slopeLimiter(cellL->Ni(iT), cellC->Ni(iT), cellR->Ni(iT), faces[i].dist, faces[i + 1].dist);
            cellC->sEe(iT)   = slopeLimiter(cellL->Ee(iT), cellC->Ee(iT), cellR->Ee(iT), faces[i].dist, faces[i+1].dist);
            cellC->sPhi(iT)  = slopeLimiter(cellL->Phi(iT), cellC->Phi(iT), cellR->Phi(iT), faces[i].dist, faces[i+1].dist);
        }
    }
    // Set the slopes at the boundary cells
    for (label iT = 0; iT < numT; ++iT)
    {
        cells[numCells].sNe(iT)      = 0.0;
        cells[numCells].sNi(iT)      = 0.0;
        cells[numCells].sEe(iT)      = 0.0;
        cells[numCells].sPhi(iT)     = 0.0;

        cells[numCells + 1].sNe(iT)  = 0.0;
        cells[numCells + 1].sNi(iT)  = 0.0;
        cells[numCells + 1].sEe(iT)  = 0.0;
        cells[numCells + 1].sPhi(iT) = 0.0;
    }
}

void FVM::Solver::evolve()
{
    using Const::numNodes;
    for (auto &face : faces)
    {
        // Obtain the values at right and left sides of the faces
        face.interpolate();
        if (face.faceID == 0)
        {
            face.getFluxLeftBC();
        }
        else if (face.faceID == numNodes - 1)
        {
            face.getFluxRightBC();  
        }
        else
        {
            face.getFlux();
        }  
    }
}



void FVM::Solver::updateFluidImplicitE(const label iRK)
{
    using namespace Const;
    using namespace Tools;

    Eigen::MatrixXd Eye = Eigen::MatrixXd::Identity(Const::numT, Const::numT);



    for (label i = 0; i < numMesh; ++i)
    {
        Eigen::MatrixXd MatrixK = Eigen:: MatrixXd::Zero(numT, numT);
        Eigen::VectorXd ResFluxNe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResFluxNi = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResFluxEe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd Ne1 = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd Ni1 = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd Ee1 = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResSourceENe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResSourceENi = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResSourceEEe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResSourceKNe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResSourceKNi = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd ResSourceKEe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd DNe = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd DNi = Eigen::VectorXd::Zero(numT);
        Eigen::VectorXd DEe = Eigen::VectorXd::Zero(numT);
        Eigen::MatrixXd implicitOperator1 = Eye + Const::eps * cells[i].dt * harmMat;
        Eigen::MatrixXd implicitOperator1Inv = implicitOperator1.inverse();

        for (label iT = 0; iT < numT; ++iT)
        {
            //- Splitting: Stage 1

            ResFluxNe(iT) = alpha[iRK] * ( faces[i].fluxNe(iT) - faces[i+1].fluxNe(iT) ) * cells[i].dt/dx;
            ResFluxNi(iT) = alpha[iRK] * ( faces[i].fluxNi(iT) - faces[i+1].fluxNi(iT) ) * cells[i].dt/dx;
            ResFluxEe(iT) = alpha[iRK] * ( faces[i].fluxEe(iT) - faces[i+1].fluxEe(iT) ) * cells[i].dt/dx;
            ResFluxEe(iT) += alpha[iRK] * ( faces[i].fluxEeJoule(iT) - faces[i+1].fluxEeJoule(iT) ) * cells[i].Phi(iT) * cells[i].dt/dx;
            Ne1(iT) = cells[i].NeOld(iT) + ResFluxNe(iT);
            Ni1(iT) = cells[i].NiOld(iT) + ResFluxNi(iT);
            Ee1(iT) = cells[i].EeOld(iT) + ResFluxEe(iT);
            //cells[i].Te(iT) = EeToTe(cells[i].Ne(iT), cells[i].Ee(iT));

            //- Splitting: Stage 2
            const scalar TeV = KToeV( EeToTe(Ne1(iT), Ee1(iT)) );
            const scalar kl = chemSets.interpolateChem(TeV);
            MatrixK(iT, iT) = kl;
            // const scalar kl = 9.75115E-17;
        }  
        
        ResSourceENe = alpha[iRK] * cells[i].dt * harmMat * Ne1;
        ResSourceENi = alpha[iRK] * cells[i].dt * harmMat * Ni1;
        ResSourceEEe = alpha[iRK] * cells[i].dt * harmMat * Ee1;

        ResSourceKNe = alpha[iRK] * cells[i].dt * MatrixK * N * Ne1;
        ResSourceKNi = alpha[iRK] * cells[i].dt * MatrixK * N * Ne1;
        ResSourceKEe = -alpha[iRK] * cells[i].dt * MatrixK * N * Ne1 * Hl;


        DNe = implicitOperator1Inv * (ResSourceKNe - ResSourceENe);
        DNi = implicitOperator1Inv * (ResSourceKNi - ResSourceENi);
        DEe = implicitOperator1Inv * (ResSourceKEe - ResSourceEEe);
        cells[i].Ne = Ne1 + DNe;
        cells[i].Ni = Ni1 + DNi;
        cells[i].Ee = Ee1 + DEe;
        for (label iT = 0; iT < numT; ++iT)
        {
            cells[i].Te(iT) = EeToTe(cells[i].Ne(iT), cells[i].Ee(iT));
        }
        

        for (label iT = 0; iT < numT; ++iT)
        {
            cells[numMesh].Ne(iT) = cells[numMesh-1].Ne(iT);
            cells[numMesh].Ni(iT) = cells[numMesh-1].Ni(iT);
            cells[numMesh].Ee(iT) = cells[numMesh-1].Ee(iT);
            cells[numMesh+1].Ne(iT) = cells[0].Ne(iT);
            cells[numMesh+1].Ni(iT) = cells[0].Ni(iT);
            cells[numMesh+1].Ee(iT) = cells[0].Ee(iT);


        }
    }

}


void FVM::Solver::updateFluidImplicitEK(const label iRK)
{
    using namespace Const;
    using namespace Tools;



    for (label i = 0; i < numMesh; ++i)
    {
        // std::cout << "Local time step =" << std::scientific << cells[i].dt << std::endl;
        for (label iT = 0; iT < numT; ++iT)
        {
            //- Splitting: Stage 1

            cells[i].ResFluxNe(iT) = alpha[iRK] * ( faces[i].fluxNe(iT) - faces[i+1].fluxNe(iT) ) * cells[i].dt/dx;
            cells[i].ResFluxNi(iT) = alpha[iRK] * ( faces[i].fluxNi(iT) - faces[i+1].fluxNi(iT) ) * cells[i].dt/dx;
            cells[i].ResFluxEe(iT) = alpha[iRK] * ( faces[i].fluxEe(iT) - faces[i+1].fluxEe(iT) ) * cells[i].dt/dx;
            cells[i].ResFluxEe(iT) += alpha[iRK] * ( faces[i].fluxEeJoule(iT) - faces[i+1].fluxEeJoule(iT) ) * cells[i].Phi(iT) * cells[i].dt/dx;
            cells[i].Ne1(iT) = cells[i].NeOld(iT) + cells[i].ResFluxNe(iT);
            cells[i].Ni1(iT) = cells[i].NiOld(iT) + cells[i].ResFluxNi(iT);
            cells[i].Ee1(iT) = cells[i].EeOld(iT) + cells[i].ResFluxEe(iT);
            //cells[i].Te(iT) = EeToTe(cells[i].Ne(iT), cells[i].Ee(iT));

            //- Splitting: Stage 2
            const scalar TeV = KToeV( EeToTe(cells[i].Ne1(iT), cells[i].Ee1(iT)) );
            const scalar kl = chemSets.interpolateChem(TeV);
            cells[i].MatrixK(iT, iT) = kl;
            // const scalar kl = 9.75115E-17;
        }   
        cells[i].ResSourceENe = alpha[iRK] * cells[i].dt * harmMat * cells[i].Ne1;
        cells[i].ResSourceENi = alpha[iRK] * cells[i].dt * harmMat * cells[i].Ni1;
        cells[i].ResSourceEEe = alpha[iRK] * cells[i].dt * harmMat * cells[i].Ee1;

        cells[i].ResSourceKNe = alpha[iRK] * cells[i].dt * cells[i].MatrixK * N * cells[i].Ne1;
        cells[i].ResSourceKNi = alpha[iRK] * cells[i].dt * cells[i].MatrixK * N * cells[i].Ne1;
        cells[i].ResSourceKEe = -alpha[iRK] * cells[i].dt * cells[i].MatrixK * N * cells[i].Ne1* Hl;


        cells[i].MatrixBJ = Const::eps * cells[i].dt * harmMat - Const::eps *cells[i].dt * cells[i].MatrixK;

        cells[i].DNeOldBJ = cells[i].ResFluxNe;
        cells[i].DNiOldBJ = cells[i].ResFluxNi;
        cells[i].DEeOldBJ = cells[i].ResFluxEe;
        
        label bjIters = 0;
        //Block-Jacobi iteration
        for(int iter = 0; iter < Const::nBJ; ++iter)
        {
            cells[i].DNe2 = cells[i].ResSourceKNe -cells[i].ResSourceENe - cells[i].MatrixBJ * cells[i].DNeOldBJ;
            cells[i].DNi2 = cells[i].ResSourceKNi - cells[i].ResSourceENi - cells[i].MatrixBJ * cells[i].DNiOldBJ;
            cells[i].DEe2 = cells[i].ResSourceKEe - cells[i].ResSourceEEe - cells[i].MatrixBJ * cells[i].DEeOldBJ;
            
            scalar errorNe = (cells[i].DNe2 - cells[i].DNeOldBJ).norm(); // L2 norm
            scalar errorNi = (cells[i].DNi2 - cells[i].DNiOldBJ).norm();
            scalar errorEe = (cells[i].DEe2 - cells[i].DEeOldBJ).norm();

            ++bjIters;

            if (errorNe < Const::tolNe && errorNi < Const::tolNi && errorEe < Const::tolEe)
            {
                break;
            }

            cells[i].DNeOldBJ = cells[i].DNe2;
            cells[i].DNiOldBJ = cells[i].DNi2;
            cells[i].DEeOldBJ = cells[i].DEe2;
            

        }

        cells[i].BJIterCount = bjIters;  


        cells[i].Ne = cells[i].Ne1 + cells[i].DNe2;
        cells[i].Ni = cells[i].Ni1 + cells[i].DNi2;
        cells[i].Ee = cells[i].Ee1 + cells[i].DEe2;
        for (label iT = 0; iT < numT; ++iT)
        {
            cells[i].Te(iT) = EeToTe(cells[i].Ne(iT), cells[i].Ee(iT));
        }
        
        for (label iT = 0; iT < numT; ++iT)
        {
            cells[numMesh].Ne(iT) = cells[numMesh-1].Ne(iT);
            cells[numMesh].Ni(iT) = cells[numMesh-1].Ni(iT);
            cells[numMesh].Ee(iT) = cells[numMesh-1].Ee(iT);
            cells[numMesh+1].Ne(iT) = cells[0].Ne(iT);
            cells[numMesh+1].Ni(iT) = cells[0].Ni(iT);
            cells[numMesh+1].Ee(iT) = cells[0].Ee(iT);

        }
    }
}



void FVM::Solver::updateFluidExplicit(const label iRK)
{
    using namespace Const;
    using namespace Tools;

    // Eigen::MatrixXd Eye = Eigen::MatrixXd::Identity(Const::numT, Const::numT);
    // Eigen::MatrixXd implicitOperator = Eye + alpha[iRK] * dt * harmMat;
    // Eigen::MatrixXd implicitOperatorInv = implicitOperator.inverse();

    for (label i = 0; i < numMesh; ++i)
    {
        for (label iT = 0; iT < numT; ++iT)
        {
            //- Splitting: Stage 1
            cells[i].Ne(iT) = cells[i].NeOld(iT) + alpha[iRK] * ( faces[i].fluxNe(iT) - faces[i+1].fluxNe(iT) ) * cells[i].dt/dx;
            cells[i].Ni(iT) = cells[i].NiOld(iT) + alpha[iRK] * ( faces[i].fluxNi(iT) - faces[i+1].fluxNi(iT) ) * cells[i].dt/dx;
            cells[i].Ee(iT) = cells[i].EeOld(iT) + alpha[iRK] * ( faces[i].fluxEe(iT) - faces[i+1].fluxEe(iT) ) * cells[i].dt/dx;
            cells[i].Ee(iT) += alpha[iRK] * ( faces[i].fluxEeJoule(iT) - faces[i+1].fluxEeJoule(iT) ) * cells[i].Phi(iT) * cells[i].dt/dx;
            

            //- Splitting: Stage 2
            const scalar TeV = KToeV( EeToTe(cells[i].Ne(iT), cells[i].Ee(iT)) );
            const scalar kl = chemSets.interpolateChem(TeV);
            // const scalar kl = 9.75115E-17;
           

            cells[i].cS(iT) = kl * cells[i].Ne(iT) * N;

            cells[i].Ne(iT) += alpha[iRK] * cells[i].dt * kl*N*cells[i].Ne(iT);
            cells[i].Ni(iT) += alpha[iRK] * cells[i].dt * kl*N*cells[i].Ne(iT);
            cells[i].Ee(iT) -= alpha[iRK] * cells[i].dt * kl*N*cells[i].Ne(iT)*Hl;
            // cells[i].Te(iT) = EeToTe(cells[i].Ne(iT), cells[i].Ee(iT));

            if ( 
                cells[i].Ne(iT) < 0.0 || cells[i].Ni(iT) < 0.0 ||
                cells[i].Ee(iT) < 0.0 || cells[i].Te(iT) < 0.0 
            )
            {
                std::cout << " Warning! Large CFL" << std::endl;
            }
        }

        //- Splitting: Stage 3
        
        cells[i].Ne -= cells[i].dt*alpha[iRK]* harmMat * cells[i].Ne;
        cells[i].Ni -= cells[i].dt*alpha[iRK]* harmMat * cells[i].Ni;
        cells[i].Ee -= cells[i].dt*alpha[iRK]* harmMat * cells[i].Ee;
      
        for (label iT = 0; iT < numT; ++iT)
        {
            cells[i].Te(iT) = EeToTe(cells[i].Ne(iT), cells[i].Ee(iT));
        }
    }

    for (label iT = 0; iT < numT; ++iT)
    {
        cells[numMesh].Ne(iT) = cells[numMesh-1].Ne(iT);
        cells[numMesh].Ni(iT) = cells[numMesh-1].Ni(iT);
        cells[numMesh].Ee(iT) = cells[numMesh-1].Ee(iT);
        cells[numMesh+1].Ne(iT) = cells[0].Ne(iT);
        cells[numMesh+1].Ni(iT) = cells[0].Ni(iT);
        cells[numMesh+1].Ee(iT) = cells[0].Ee(iT);

    }
}


void FVM::Solver::setBoundaryConditions(const Eigen::VectorXd &harmTime)
{
    using namespace Const;
    Cell *cellLBC = &cells[numCells + 1];
    Cell *cellRBC = &cells[numCells];
    
    for(label iT = 0; iT < numT; +iT)
    {
        cellLBC->Ne(iT)  = cells[0].Ne(iT);
        cellLBC->Ni(iT)  = cells[0].Ni(iT);
        cellLBC->Ee(iT)  = cells[0].Ee(iT);
        cellLBC->Te(iT)  = cells[0].Te(iT);
        if (analysisMode == AnalysisMode::STEADY)
        {
            cellLBC->Phi(iT) = PhiRF;
        }
        else
        {
            cellLBC->Phi(iT) = PhiRF * std::sin(2.0 * pi * fRF * harmTime(iT) + phase); 
        }
        
        cellRBC->Ne(iT) = cells[numCells - 1].Ne(iT);
        cellRBC->Ni(iT) = cells[numCells - 1].Ni(iT);
        cellRBC->Ee(iT) = cells[numCells - 1].Ee(iT);
        cellRBC->Te(iT) = cells[numCells - 1].Te(iT);
        cellRBC->Phi(iT) = 0.0;
    }
}

void FVM::Solver::writeFourierCoefficients(label step)
{
    std::stringstream fileName;
    fileName << outputDir << "/fourier_coeff.dat";  


    std::ifstream checkFile(fileName.str().c_str());
    bool fileExists = checkFile.good();
    checkFile.close();

    std::ofstream outFourier;
    if (fileExists) {

        outFourier.open(fileName.str().c_str(), std::ios::app); 
    } else {
        outFourier.open(fileName.str().c_str(), std::ios::out); 
    }


    if (!outFourier.is_open()) {
        std::cerr << "Error: Cannot open file " << fileName.str() << std::endl;
        return;
    }

    // Write the header only once, if it's the first step (i.e., file didn't exist before)
    static bool headerWritten = false;
    if (!headerWritten) {
        outFourier << "variables = X, Ne_mean, Ni_mean, Te_mean, Phi_mean";
        for (label k = 1; k <= Const::numH; ++k) {
            outFourier << ", Ne_real_" << k << ", Ne_imag_" << k
                       << ", Ni_real_" << k << ", Ni_imag_" << k
                       << ", Te_real_" << k << ", Te_imag_" << k
                       << ", Phi_real_" << k << ", Phi_imag_" << k;
        }
        outFourier << std::endl;
        headerWritten = true;
    }

    // Write data for the current step into a "zone" section with the proper format
    outFourier << "ZONE T=\"Step_" << step << "\", I=" << Const::numMesh << ", F=POINT\n";

    for (label i = 0; i < Const::numMesh; i++) {
        const Eigen::VectorXd HatNe = dftMatInv * cells[i].Ne;
        const Eigen::VectorXd HatNi = dftMatInv * cells[i].Ni;
        const Eigen::VectorXd HatTe = dftMatInv * cells[i].Te;
        const Eigen::VectorXd HatPhi = dftMatInv * cells[i].Phi;

        outFourier << std::setprecision(10) << cells[i].cellID
                   << " " << HatNe(0) << " " << HatNi(0) << " " << HatTe(0) << " " << HatPhi(0);

        for (label k = 1; k <= Const::numH; ++k) {
            outFourier << " " << HatNe(2 * k - 1) << " " << HatNe(2 * k)
                       << " " << HatNi(2 * k - 1) << " " << HatNi(2 * k)
                       << " " << HatTe(2 * k - 1) << " " << HatTe(2 * k)
                       << " " << HatPhi(2 * k - 1) << " " << HatPhi(2 * k);
        }

        outFourier << std::endl;
    }

    outFourier.close();
}





void FVM::Solver::writeTransientSolution(label step)
{
    using namespace Const;
    std::stringstream fileName1;
    fileName1 << outputDir << "/reconstructed_solution.dat";

    std::ifstream checkFile(fileName1.str().c_str());
    bool fileExists = checkFile.good();
    checkFile.close();

    std::ofstream outSolution;
    if (fileExists) {

        outSolution.open(fileName1.str().c_str(), std::ios::app); 
    } else {
        outSolution.open(fileName1.str().c_str(), std::ios::out); 
    }

    if (!outSolution.is_open()) {
        std::cerr << "Error: Cannot open file " << fileName1.str() << std::endl;
        return;
    }

    outSolution << "variables = X, nE, nI, Te(K), Te(eV), Phi" << std::endl;

    for (label nIn = 0; nIn < Const::numInstants; ++nIn)
    {
        scalar toverT = (1.0 * nIn) / Const::numInstants; 
        scalar t = toverT * Const::period;

        Eigen::VectorXd phaseT = angFreq * t;

   


        outSolution << "ZONE T=\"Step_" << step << "_t=" << toverT << "T\",  I=" << Const::numMesh << ", F=POINT" << std::endl;


        Eigen::VectorXd Ne(Const::numMesh);
        Eigen::VectorXd Ni(Const::numMesh);
        Eigen::VectorXd Te(Const::numMesh);
        Eigen::VectorXd Phi(Const::numMesh);


        std::vector<double> cosPhase(Const::numH);
        std::vector<double> sinPhase(Const::numH);
        for (label nh = 0; nh < Const::numH; ++nh) {
            cosPhase[nh] = cos(phaseT(nh));
            sinPhase[nh] = sin(phaseT(nh));
        }


        for (label i = 0; i < Const::numMesh; ++i)
        {

            const Eigen::VectorXd HatNe = dftMatInv * cells[i].Ne;
            const Eigen::VectorXd HatNi = dftMatInv * cells[i].Ni;
            const Eigen::VectorXd HatTe = dftMatInv * cells[i].Te;
            const Eigen::VectorXd HatPhi = dftMatInv * cells[i].Phi;


            Ne(i) = HatNe(0);
            Ni(i) = HatNi(0);
            Te(i) = HatTe(0);
            Phi(i) = HatPhi(0);

            for (label nh = 0; nh < Const::numH; ++nh)
            {
                Ne(i) += HatNe(2 * nh + 1) * cosPhase[nh] + HatNe(2 * nh + 2) * sinPhase[nh];
                Ni(i) += HatNi(2 * nh + 1) * cosPhase[nh] + HatNi(2 * nh + 2) * sinPhase[nh];
                Te(i) += HatTe(2 * nh + 1) * cosPhase[nh] + HatTe(2 * nh + 2) * sinPhase[nh];
                Phi(i) += HatPhi(2 * nh + 1) * cosPhase[nh] + HatPhi(2 * nh + 2) * sinPhase[nh];
            }


            outSolution << std::setprecision(10)
                        << cells[i].cellID << " "
                        << Ne(i) << " "
                        << Ni(i) << " "
                        << Te(i) << " "
                        << Tools::KToeV(Te(i)) << " "
                        << Phi(i) << std::endl;
        }

    
    }
    outSolution.close();
}



void FVM::Solver::writeQuasiSteadySolution(label step)
{
    std::stringstream fileName;
    fileName << outputDir << "/qusisteady_solution.dat";

    std::ifstream checkFile(fileName.str().c_str());
    bool fileExists = checkFile.good();
    checkFile.close();

    std::ofstream outFile;
    if (fileExists) {

        outFile.open(fileName.str().c_str(), std::ios::app); 
    } else {
        outFile.open(fileName.str().c_str(), std::ios::out); 
    }


    outFile << "TITLE=\"Qusi Steady Data\"" << std::endl;
    outFile << "VARIABLES=\"X\", \"Ne\", \"Ni\", \"Te\", \"Phi\"" << std::endl;


    for (label iT = 0; iT < Const::numT; iT++)
    {
        

        outFile << "ZONE T=\"Step_" << step << "_TimeInstant=" << iT << "\",I=" << Const::numMesh << ", F=POINT" << std::endl;




        for (label i = 0; i < Const::numMesh; i++)
        {
            outFile << std::setprecision(10)
                    << cells[i].cellID << " " // X
                    << cells[i].Ne(iT) << " " // Ne
                    << cells[i].Ni(iT) << " " // Ni
                    << cells[i].Te(iT) << " " // Te
                    << cells[i].Phi(iT) << std::endl; // Phi
        }
    }

    outFile.close();
}


void FVM::Solver::gridMetrics()
{
    using namespace Const;

    // Compute cell volumes
    for(label i = 0; i < numCells; ++i)
    {
        cells[i].vol = coords[i + 1].x - coords[i].x; 
    }
    // cell volume for the ghost cell(face element) at the right boundary
    cells[numCells].vol = 0.0; 

    // cell volume for the ghost cell(face element) at the left boundary
    cells[numCells  + 1].vol = 0.0;

    // Compute face distances
    for (label i = 0; i < numNodes; ++i) {
        if (i == 0) {
            faces[i].dist  = 0.5 * cells[i].vol;
            faces[i].distL = 0.0; 
            faces[i].distR = 0.5 * cells[i].vol;
        }
        else if (i == numNodes - 1) {
            faces[i].dist  = 0.5 * cells[i - 1].vol;
            faces[i].distL = 0.5 * cells[i - 1].vol;
            faces[i].distR = 0.0;
        }
        else {
            faces[i].dist  = 0.5 * (cells[i].vol + cells[i - 1].vol);
            faces[i].distL = 0.5 * cells[i - 1].vol;
            faces[i].distR = 0.5 * cells[i].vol;
        }
    }
}


void FVM::Solver::readQuasiSteadySolution(const std::string& filePath)
{
    using namespace Const;
    std::ifstream inFile(filePath.c_str());

    if (!inFile.is_open()) {
        std::cerr << "Error: Cannot open file " << filePath << std::endl;
        return;
    }

    std::string line;

  
    while (std::getline(inFile, line)) {
        if (line.find("ZONE") != std::string::npos) {
            break;  
        }
    }

    label iT = 0; 
    while (true)
    {

        if (line.find("ZONE") != std::string::npos)
        {

            size_t pos = line.find("T=\"TimeInstant_");
            if (pos != std::string::npos)
            {
                std::string timeStr = line.substr(pos + 15); 
                iT = std::stoi(timeStr.substr(0, timeStr.find("\"")));  
            }


            if (!std::getline(inFile, line)) break;
        }


        std::istringstream iss(line);
        label cellID;
        double Ne_val, Ni_val, Te_val, Phi_val;

        if (!(iss >> cellID >> Ne_val >> Ni_val >> Te_val >> Phi_val)) {

            if (!std::getline(inFile, line)) break;
            continue;
        }


        for (label i = 0; i < numCells; i++)
        {
            if (cells[i].cellID == cellID)  
            {
                cells[i].Ne(iT)  = Ne_val;
                cells[i].Ni(iT)  = Ni_val;
                cells[i].Te(iT)  = Te_val;
                cells[i].Phi(iT) = Phi_val;
                break;
            }
        }

       
        if (!std::getline(inFile, line)) break;
    }

    inFile.close();
}



void FVM::Solver::info()
{
    using std::cout;
    using std::endl;
    using Const::fRF;

    // cout << "step = " << step << "\t"
    //      << "runTime = " << runTime << " (s) \t"
    //      << "dt = " 
    //      << dt << " (s) "
    //      << " = " << dt * fRF << " (cyc/step)" 
    //      << " in " 
    //      << Tools::toStringFill0(runTime * fRF) << " th period."
    //      << endl;
}


void FVM::Solver::writeResidual(label step, scalar logResNe, scalar logResNi, scalar logResTe)
{
    const std::string filename = "residuals.dat";
    static bool firstWrite = true;

    std::ofstream out;
    if (firstWrite)
    {

        out.open(filename, std::ios::out);
        out << "TITLE = \"Residual History\"\n";
        out << "VARIABLES = \"Step\", \"log10(Res_Ne)\", \"log10(Res_Ni)\", \"log10(Res_Te)\"\n";
        out << "ZONE T=\"Residuals\", F=POINT\n";
        firstWrite = false;
    }
    else
    {

        out.open(filename, std::ios::app);
    }

    out << step << " " << logResNe << " " << logResNi << " " << logResTe << "\n";
    out.close();
}



void FVM::Solver::appendBJIterCount(label step)
{
    const std::string filename = "bj_iters_all.dat";
    std::ofstream out;

    if (step == 0)
    {
        out.open(filename, std::ios::out);
        out << "TITLE = \"Block-Jacobi Iterations\"\n";
        out << "VARIABLES = \"CellID\", \"BJ_Iterations\"\n";
    }
    else
    {
        out.open(filename, std::ios::app);
    }


    out << "ZONE T=\"Step_" << step << "\", I=" << Const::numMesh << ", F=POINT\n";


    for (label i = 0; i < Const::numMesh; ++i)
    {
        out << i << " " << cells[i].BJIterCount << "\n";
    }

    out.close();
}


void FVM::Solver::infoRes()
{

    scalar resNe = 0.0;
    scalar resNi = 0.0;
    scalar resTe = 0.0;

    for (label i = 0; i < Const::numMesh; ++i)
    {
        

        scalar neNew  = cells[i].Ne(0);
        scalar neOld  = cells[i].NeOld(0);
        scalar niNew  = cells[i].Ni(0);
        scalar niOld  = cells[i].NiOld(0);
        scalar teNew  = cells[i].Te(0);
        scalar teOld  = cells[i].TeOld(0);
        scalar denomne   = std::max(std::abs(neOld), 1e-10);  
        scalar denomni   = std::max(std::abs(niOld), 1e-10);  
        scalar denomte  =  std::max(std::abs(teOld), 1e-10);  
    
        resNe += pow((neNew - neOld) / denomne, 2);
        resNi += pow((niNew - niOld) / denomni, 2);
        resTe += pow((teNew - teOld) / denomte, 2);


        
    }
    resNe = sqrt(resNe / Const::numMesh);
    resNi = sqrt(resNi / Const::numMesh);
    resTe = sqrt(resTe / Const::numMesh);


    scalar logResNe = log10(resNe + 1e-20);
    scalar logResNi = log10(resNi + 1e-20);
    scalar logResTe = log10(resTe + 1e-20);


    if (step % Const::printInterval == 0)
    {
        std::cout << "step = " << step 
                << " Residual (log10 L2): Ne = " << logResNe 
                << ", Ni = " << logResNi 
                << ", Te = " << logResTe << std::endl;
    }

    writeResidual(step, logResNe, logResNi, logResTe);
}

void FVM::Solver::iterateExplicit()
{

    using namespace Const;
    scalar cyc = 0.0;
    bool negativeValueDetected = false;
    bool isAveraging = false;     
    bool isAveWritten = false;    
    auto stepStart = std::chrono::high_resolution_clock::now();

    if (stopMode != StopMode::TIME &&
        stopMode != StopMode::STEP &&
        stopMode != StopMode::PERIOD) 
    {
        std::cerr << "[Error] Invalid stopMode before entering loop!" << std::endl;
        exit(EXIT_FAILURE);
    }

    while (
        stopMode == StopMode::TIME   ? runTime < stopTime :
        stopMode == StopMode::STEP   ? step    < stopStep :
        stopMode == StopMode::PERIOD ? runCyc  < stopPeriod :
        false
    )
    {
        // Get the time step for each cell
        getDt();

        // Store the conservative variables from the last step 
        initRK();

        // Runge-Kutta iteration
        label iRK = 0;
        while ( iRK < nRK )
        {
    
            // Setup the boundary conditions
            setBoundaryConditions(harmTime);

            // Get the slopes based on MUSCL limiter
            calSlope();

            // Get the fluxes of each face
            evolve();
            
            updateFluidImplicitEK(iRK);

            iRK++;
        }

        if (step % Const::writeInterval == 0)
        {
            appendBJIterCount(step);
        }
        step++;

        for (label i = 0; i < Const::numMesh; ++i)
        {
            for (label iT = 0; iT < Const::numT; ++iT)
            {
                if ( 
                    cells[i].Ne(iT) < 0.0 || cells[i].Ni(iT) < 0.0 ||
                    cells[i].Ee(iT) < 0.0 || cells[i].Te(iT) < 0.0 
                )
                {
                    std::cout << " Error: Negative value detected!" << std::endl;
                    negativeValueDetected = true;
                    break;
                }
            }

            if  (negativeValueDetected)
            {
                break;
            }

        }


        infoRes();
        // writeFourierCoefficients("End", 0);


        if (step % Const::writeInterval== 0)
        {
            writeFourierCoefficients(step);
            writeQuasiSteadySolution(step);
            writeTransientSolution(step);    
        }
    }
}


void FVM::Solver::iterateHBImplicit123()
{
    // scalar cyc = 0.0;
    // scalar lastCyc = Const::stopPeriod - 1.0;
    // scalar zoomInCyc = 0.0;
    bool negativeValueDetected = false;


    if (Const::initOption != "scratch") {
        std::cout << "Read quasi-steady solution from file." << std::endl;
        readQuasiSteadySolution(Const::initFile);
    }

    initlize(); // set boundary: two ghost cells

    initHarmonicMat();

    initMassMat();
    // updatePhiFEM();
    // updatePhiFEMMatDec();

    while (
        runTime < Const::stopTime    && 
        step    < Const::stopStep    &&
        runCyc  < Const::stopPeriod
    )
    {

        getDt();

        label iRK = 0;

        initRK();

        while ( iRK < Const::nRK )
        {
            updatePhiFEMMatDec();

            reconstruct();

            evolve();
            
            // updateFluidExplicit(iRK);
            updateFluidImplicitEK(iRK);
            // updateFluidImplicitE(iRK);
            iRK++;
        }

        if (step % Const::writeInterval == 0)
        {
            appendBJIterCount(step);
        }
        step++;

        for (label i = 0; i < Const::numMesh; ++i)
        {
            for (label iT = 0; iT < Const::numT; ++iT)
            {
                if ( 
                    cells[i].Ne(iT) < 0.0 || cells[i].Ni(iT) < 0.0 ||
                    cells[i].Ee(iT) < 0.0 || cells[i].Te(iT) < 0.0 
                )
                {
                    std::cout << " Error: Negative value detected!" << std::endl;
                    negativeValueDetected = true;
                    break;
                }
            }

            if  (negativeValueDetected)
            {
                break;
            }

        }


        infoRes();
        // writeFourierCoefficients("End", 0);


        if (step % Const::writeInterval== 0)
        {
            writeFourierCoefficients(step);
            writeQuasiSteadySolution(step);
            writeTransientSolution(step);    
        }
    }
}

int main(int argc, char *argv[])
{
    using namespace Const;
    freopen("debug.log", "w", stdout);         // 
    freopen("debug_error.log", "w", stderr);    // 
    std::cout.setf(std::ios::unitbuf);

    PetscInitialize(&argc, &argv, NULL, NULL);


    std::string caseFile;  

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-c" && i + 1 < argc) {
            caseFile = argv[i + 1];
            i++;
        }
    }   
    if (caseFile.empty()) {
        std::cerr << "Error: Missing -c <config_file>" << std::endl;
        PetscFinalize();
        return 1;
    }

    std::cout << "Loading case file: " << caseFile << std::endl;
    // Read Input Configuration File
    readConfigFile(caseFile);

    std::cout << "Scaling to dimensionless variables" << std::endl;
    // Reading the mesh file
    readMeshFile(meshFile);

    std::cout << "Non-dimensionalizing the parameters and variables" << std::endl;
    // Non-dimensionalize the Parameters and Variables
    scaleToDimensionless();
    
    std::cout << "Initializing the FVM Solver" << std::endl;
    // Initialize the Solver
    FVM::Solver ccp;

    // Calculating the metrics of the grid
    std::cout << "Calculating the grid metrics" << std::endl;
    ccp.gridMetrics();

    // Initializing the varaibles from default values or from the file
    std::cout << "Initializing the variables" << std::endl;
    ccp.initlize(); 

    // Initializing the harmonic matrix
    std::cout << "Initializing the matrices and vectors related to harmonic balance method" << std::endl;
    ccp.initHarmonicMat();


    if(analysisMode == AnalysisMode::HB)
    {
        if(implicitScheme == ImplicitScheme::PCI1)
        {
            std::cout << "Running HB Implicitly coupling governing equations 1 2 3!" << std::endl;
            ccp.iterateHBImplicit123();
        }
        else if (implicitScheme == ImplicitScheme::NO)
        {   
            std::cout << "Running HB Explicitly!" << std::endl;
            ccp.iterateExplicit();
        }
        
    }
    else if (analysisMode == AnalysisMode::DT)
    {
        std::cout << "Running DT!" << std::endl;
        ccp.iterateExplicit(); 
    }
    


    return 0;
}

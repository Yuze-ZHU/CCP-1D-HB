#ifndef HARMOIC_HPP
#define HARMOIC_HPP

void constructE();
#endif
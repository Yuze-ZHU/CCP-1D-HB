#include "harmonic.hpp"
#include "../eigen-3.3.9/Eigen/Dense"
#include "../eigen-3.3.9/Eigen/Sparse"

#include <cmath>
#include <iostream>
#include <iomanip>

void constructE()
{
    std::cout << "Construct E." << std::endl;

    const int nharm = 3;
    const int nTs = 2 * nharm + 1;
    const double freq = 13.56e6;
    const double T = 1.0 / freq;
    double dtheta;

    Eigen::VectorXd t(nTs);
    t.setZero();

    for (int nT = 0; nT < nTs; ++nT)
    {
        t(nT) = nT * T / nTs;
        std::cout << "t(" << nT << ") = " << t(nT) << std::endl;
    }

    

    Eigen::VectorXd angFreq(nharm);
    angFreq.setZero();

    for (int nh = 0; nh < nharm; ++nh)
    {
        angFreq(nh) = 2.0 * M_PI * (nh+1) * freq;
        std::cout << "angFreq(" << nh << ") = " << angFreq(nh) << std::endl;
    }

    Eigen::MatrixXd D(nTs, nTs);

    Eigen::MatrixXd Dt(nTs, nTs);

    Eigen::MatrixXd E(nTs, nTs);

    D.setZero();
    
    Dt.setZero();

    E.setZero();
    for (int nT = 0; nT < nTs; ++nT)
    {
        D(nT,0) = 1.0;
        Dt(nT,0) = 0.0;

        for (int nh = 0; nh < nharm; ++nh)
        {   
            dtheta = angFreq(nh) * t(nT);
            D(nT, 2*nh+1) = sin(dtheta);
            D(nT, 2*nh+2) = cos(dtheta);
            Dt(nT, 2*nh+1) = angFreq(nh) * cos(dtheta);
            Dt(nT, 2*nh+2) = -angFreq(nh) * sin(dtheta);
        }
    }

    std::cout << "\nMatrix D:" << std::endl;
    for (int i = 0; i < nTs; ++i) {
        for (int j = 0; j < nTs; ++j) {
            std::cout << std::setw(20) << std::fixed << std::setprecision(8) << D(i, j) << " ";
        }
        std::cout << std::endl;
    }

    std::cout << "\nMatrix Dt:" << std::endl;
    for (int i = 0; i < nTs; ++i) {
        for (int j = 0; j < nTs; ++j) {
            std::cout << std::setw(20) << std::fixed << std::setprecision(8) << Dt(i, j) << " ";
        }
        std::cout << std::endl;
    }

    Eigen::MatrixXd D_inv;


    D_inv.setZero();

    D_inv = D.inverse();


    std::cout << "\nMatrix D_inv:" << std::endl;
    for (int i = 0; i < nTs; ++i) {
        for (int j = 0; j < nTs; ++j) {
            std::cout << std::setw(20) << std::fixed << std::setprecision(8) << D_inv(i, j) << " ";
        }
        std::cout << std::endl;
    }

    E = Dt * D_inv;
    
    std::cout << "\nMatrix E:" << std::endl;
    for (int i = 0; i < nTs; ++i) {
        for (int j = 0; j < nTs; ++j) {
            std::cout << std::setw(20) << std::fixed << std::setprecision(8) << E(i, j) << " ";
        }
        std::cout << std::endl;
    }







    

}

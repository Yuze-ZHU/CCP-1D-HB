#include "ccp-1d.hpp"
#include "Const.hpp"
#include <iostream>



// -------------------------------------------------------//
//  _______  _______  _______          __    ______       //
// (  ____ \(  ____ \(  ____ )        /  \  (  __  \      //
// | (    \/| (    \/| (    )|        \/) ) | (  \  )     //
// | |      | |      | (____)| _____    | | | |   ) |     //
// | |      | |      |  _____)(_____)   | | | |   | |     //
// | |      | |      | (                | | | |   ) |     //
// | (____/\| (____/\| )              __) (_| (__/  )     //
// (_______/(_______/|/               \____/(______/      //
//                                                        //
// -------------------------------------------------------//
//                                                        //
// Description:                                           //
// Contains Const, Solver, Tools                          //
//                                                        //
// -------------------------------------------------------//

#include <valarray>
#include <vector>
#include <string>
#include <cmath>
#include <array>
#include "def.hpp"
#include <petsc.h>

#include "../eigen-3.3.9/Eigen/Dense"
#include "../eigen-3.3.9/Eigen/Sparse"

// Typedefs

using label = long long int;
using scalar = double;
using tensor1 = std::valarray<scalar>;
using tensor2 = std::valarray<std::valarray<scalar>>;
using std::vector;


namespace Tools
{
    // Mathematic

    scalar abs(const scalar num);

    tensor1 sign(const tensor1 &array);
    
    scalar sign(const scalar &value);

    scalar max(const scalar a, const scalar b);

    scalar min(const scalar a, const scalar b);

    // Basic Kinetic Formula

    scalar KToeV(const scalar K);

    scalar eVtoK(const scalar eV);

    scalar TeToEe(const scalar Ne, const scalar Te);

    scalar TeToEeND(const scalar Ne, const scalar Te);

    scalar EeToTe(const scalar Ne, const scalar Ee);

    scalar EeToTeND(const scalar Ne, const scalar Ee);

    std::string toString(double value, int precision);

    std::string toStringFill0(double value);

    std::vector<PetscScalar> toRowMajor(const Eigen::MatrixXd& M);
}


namespace FVM
{

    // Basic Element for Finite Volume Element

    struct ChemRate
    {
        double energy;
        double cRate;
    };
    
    class ChemSet
    {

    public:
        // Member Variables

        //- Sets of Chemial Reaction Rate 
        vector<ChemRate> chemSets;

        // Constructor

        //- Constructed by .csv file
        explicit ChemSet(const std::string csvName);

        // Destructor
        ~ChemSet();

        // Member function
        scalar interpolateChem(const scalar Te);

    };

    class PhiDecSolver
    {

    public:
        // Member Variables

        //- 
        Eigen::MatrixXd M;

        //- 
        Eigen::LLT<Eigen::MatrixXd> solver;

        //- Constructor
        explicit PhiDecSolver();

        // Member Functions

        //- Create LU Matrixes
        void createLU();

        //- 
        void solverApply(Eigen::VectorXd &F,Eigen::VectorXd &Phi_);
        
        // Destructor
        ~PhiDecSolver();
    };

    class Cell
    {
    public:
        // Member Variables

        // Geometry
        // - Volume of the cell
        scalar vol;

        //- Cell ID
        label cellID;

        //- Physical time step
        scalar dt;

        // - Pseudo time step
        scalar dtau;

        //- Rate coefficient 
        scalar kl;

        // Conservative variables
        Eigen::VectorXd Ne, Ni, Ee, Phi;

        // Primitive variables
        Eigen::VectorXd Te, Ec;

        //- Other variables
        Eigen::VectorXd Je, Ji, cS;

        //- Conservative variables at the previous time step
        Eigen::VectorXd NeOld, NiOld, EeOld, PhiOld;

        //- Residual flux of conservative variables(including flux and source term, updating the conservative variables) 
        Eigen::VectorXd ResFluxNe, ResFluxNi, ResFluxEe, ResFluxPhi;
        
        //- Slope of conservative variables
        Eigen::VectorXd sNe, sNi, sEe, sPhi;

        //- Residual of conservative variables(output of the residual calculation)
        Eigen::VectorXd resNe, resNi, resEe;

        //- Matrix for the chemical reaction
        Eigen::MatrixXd MatrixK;

        // Constructor
        //- Construct by id
        explicit Cell(const label i);

        // Destructor
        ~Cell();
    };

    class Parcel
    {
    };

    class Face
    {

    public:
        // Member Variables

        //- Cells at left and right side
        const Cell &cellL, &cellR;

        //- Face ID
        label faceID;

        //- Cell ID
        label cellIDL, cellIDR;

        //- Distance between the centers of the left and right cells
        scalar dist;

        //- Distance between the center of the left cell and the face
        scalar distL;

        //- Distance between the center of the right cell and the face
        scalar distR;

        //- Conservative and primitive variables at left and right sides
        Eigen::VectorXd NeL, NeR;
        Eigen::VectorXd NiL, NiR;
        Eigen::VectorXd EeL, EeR;
        Eigen::VectorXd TeL, TeR;
        Eigen::VectorXd PhiL, PhiR;
        Eigen::VectorXd Ef;

        //- Flux for number density, electron energy and electric field
        Eigen::VectorXd fluxNe, fluxNi;
        Eigen::VectorXd fluxEe;
        Eigen::VectorXd fluxEeJoule;
        Eigen::VectorXd fluxPhi;

        // Constructor
        //- Construct by cells
        explicit Face(const Cell &Lcell, const Cell &Rcell);

        // Destructor
        ~Face();

        // Member function

        //- Interpolate to face
        void interpolate();

        //- Calculate diffusion term interface
        scalar getDiff(const scalar pLcell, const scalar pRcell);

        //- Calculate upwind term at cell interface for electron
        scalar getUpwind(const scalar pLcell, const scalar pRcell, const label iT);

        //- Calculate downwind term at cell interface for electron
        scalar getDownwind(const scalar pLcell, const scalar pRcell, const label iT);

        //- Calculate Flux
        void getFlux();
        void getFluxLeftBC();
        void getFluxRightBC();
    };

    class Solver
    {
    public:
        // Member Variables

        //- Iteration step
        label step;

        //- Run time
        scalar runTime;
        
        //- Run period
        label runCyc;

        //- Time step
        scalar dtminGlobal;

        //- Is negative 
        bool isWarning;

        //- Output directory
        std::string outputDir;

        //- Matrix Solver
        PhiDecSolver phisolver;

        //- Chemical reacting set
        ChemSet chemSets;

        //- Basic FVM for cell
        vector<Cell> cells;

        //- Basic FVM for face
        vector<Face> faces;

        // Matrices  and vectors related to Harmonic Balance
        //- Time spectral source matrix, E
        Eigen::MatrixXd harmMat;

        //- DFT matrix, D
        Eigen::MatrixXd dftMat;

        //- Inverse of DFT matrix, D^-1
        Eigen::MatrixXd dftMatInv;
 
        //- Time instants
        Eigen::VectorXd harmTime;

        //- Angular frequencies
        Eigen::VectorXd angFreq;

        // Module for solving Poisson's equation using the FVM framework: A·x = b
        //- Coefficient matrix A for the discretized Poisson's equation
        Mat poissonMat;

        //- Solution vector x, containing the electric potential (phi) values at each cell
        Vec phiVec;

        //- Right-hand side vector b, including source terms and boundary conditions
        Vec phiRhsVec;

        // Constructor
        Solver();

        // Destructor
        ~Solver();

        // Member function

        //- Initialize the flow region
        void initlize();

        //- Initialize the Harmonic Matrix
        void initHarmonicMat();

        //- Calculate the metrics for the grid
        void gridMetrics();


        //- Read solution from the initial file
        void readQuasiSteadySolution(const std::string& filePath);

        //- Calculate time step
        void getDt();

        //- Initialize Runge-Kutta
        void initRK();

        //- Calculate the slope of the variables
        void calSlope();

        //- Evolution
        void evolve();

        //- Solving
        void iterateExplicit();
        void iterateHBImplicit123();

        //- Update fluid field
        void updateFluidExplicit(const label iRK);
        void updateFluidImplicitEK(const label iRK);
        void updateFluidImplicitE(const label iRK);

        //- Update Phi for electric potential
        void updatePhiFVM();


        //- Boundary condition setup
        void setBoundaryConditions(const Eigen::VectorXd &harmTime);

        // void JacobianAssembly(Eigen::MatrixXd &J, Eigen::VectorXd &F, const label iT);


        //- Sumation for Average

        //- Write
        void writeFourierCoefficients(label step);
        void writeTransientSolution(label step);
        void writeQuasiSteadySolution(label step);
        void writeResidual(label step, scalar logResNe, scalar logResNi, scalar logResTe);
        void appendBJIterCount(label step);

        //- Print information
        void info();

        //- Print information
        void infoRes();


    };

}
